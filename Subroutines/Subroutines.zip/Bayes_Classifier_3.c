/*
Bayes_Chassifier_3.c

PURPOSE

    This Program uses Bayes rule to classify random measurements into 2 classes.

INPUT ARGUMENTS

A file in this format:
Number of Measurements
Number of repetitions
A random seed

OUTPUT

The percent correctness for each trial

*/


// These are needed to print and choose random numbers
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// These are all the subroutines
#include "Bayes_Rule.h"
#include "Correctness_Checker.h"
#include "FillClassArray.h"
#include "InitFloatArray.h"
#include "InitFloatVector.h"
//#include "PrintFloatArray.h"
#include "PrintFloatVector.h"
#include "PrintIntArray.h"
#include "PrintIntVector.h"
#include "Shuffle.h"
#include "TrueClassArray.h"

// define the number of classes

// define the file that the user edits
#define dataFile "testData.dat"
#define plotDataFile "plotData.csv"

// define the debug feature
#define TODEBUG 1

int main(){
    // used for for loops
    int i,j,k; 
    // 2 dimentional class conditional probabilities array
    float *probabilities;
    // One dimentional true class array
    int *true_class;
    // Class conditional probability arrays
    float **classarray;
    // Two arrays needed for the bayes rule
    float **cifd;
    // The assigned class array
    int *assign;
    // Correctness value
    float correctness;
    // Averaged correctness
    float avgcorecnetss;
    // Data entered by the user into the file
    int trials, ddim, cdim, seed, samples;
    float PERT=1;
    
    // File is opened and read
    FILE *fp;

    fp = fopen(dataFile, "r");
    if (fp == NULL){
        printf("ERROR! File %s not found\n",dataFile);
        exit(1);
    }
    int read_items = 0;

    // Each of the data values are scanned
    read_items+=fscanf(fp,"%d",&trials);
    read_items+=fscanf(fp,"%d",&cdim);
    read_items+=fscanf(fp,"%d",&samples);
    read_items+=fscanf(fp,"%d",&seed);

    if (read_items != 4){
        printf("File %s was found but data could not be read properly\n",dataFile);
        exit(1);
    }
    printf("Read %d %d %d %d\n",trials,cdim, samples, seed);
    ddim=samples*cdim;

    // Read File closed
    fclose(fp);
    
    fp = fopen(plotDataFile, "w");
    if (fp == NULL){
        printf("ERROR! File %s could not be written\n",plotDataFile);
        exit(1);
    }


    // Allocate Memory for arrays
    probabilities =(float *) malloc(ddim*sizeof(float));

    classarray = (float **) malloc(cdim*sizeof(float*));
    for (i=0;i<cdim;i++)
        classarray[i]=(float *) malloc(ddim*sizeof(float));

    cifd = (float **) malloc(cdim*sizeof(float*));
    for (i=0;i<cdim;i++)
        cifd[i]=(float *) malloc(ddim*sizeof(float));


    true_class= (int *) malloc(ddim*sizeof(int));
    assign= (int *) malloc(ddim*sizeof(int));

    //for(float myPERT=PERT; myPERT >=0; myPERT-=0.1){
        // Average correctness starts at 0
        avgcorecnetss = 0;

        //fprintf(fp,"%0.2f",1-myPERT);
        
        // For loop that runs for the number of trials
        for (int round=1; round <= trials; round++){
            // True class array is formed and shuffled
            trueClassArray(true_class,samples,cdim);
            shuffle(true_class,ddim,seed);

            printf("true class\n");
            printIntVector(true_class,ddim);
            printf("\n");

            // Probabilities array is filled with random floats that add up to 1
            initFloatVector(probabilities,ddim, seed);

            // Class conditional probability arrays are fileld
            fillClassArray(classarray, true_class, probabilities, cdim, ddim, 0.9,seed);

            // Bayes rule is used to assign a class to each measurement
            Bayes_Rule(classarray,cifd, assign, cdim, ddim);

            // Correctness is evaluated and averaged
            correctness=Correctness_Checker(true_class,assign,ddim);
            avgcorecnetss += correctness;

            // debugging if something goes wrong
            #if TODEBUG == 1

            printf("true class\n");
            printIntVector(true_class,ddim);
            printf("\n");
        
            printf("\n");
            printf("marginal probability of P(d) \n");
            printFloatVector(probabilities,ddim);
            printf("\n");
            printf("conditional probability of d given c P(d | c1) P(d | c2)\n");
            printFloatArray(classarray,cdim, ddim);
            printf("\n");
            printf("conditional probability of c given d P(c1 | d) and P(c2 | d)\n");
            printFloatArray(cifd,cdim,ddim);
            printf("\n");
        
            printf("assigned class\n");
            printIntVector(assign, ddim);
            printf("\n");
        
            #endif

            // The round seed, correctness is printed for each trial
            //printf("Round %d seed %u correctness %.5f\n",round,(unsigned int)seed, correctness);
            fprintf(fp,",%0.3f",correctness);
            seed = seed + 234;
        }
        fprintf(fp,"\n",correctness);


        // The average correctness is printed
        printf("PERT: %0.3f - Ran %d runs using %d measurements in the measurement space and averaged %.5f accuracy\n",1-1,trials,ddim,avgcorecnetss/trials);
    //}

    // Memory is freed
    for (i=0;i<cdim;i++){
        free(classarray[i]);
        free(cifd[i]);
    }
    free(probabilities);
    free(true_class);
    free(classarray);
    free(cifd);
    free(assign);

    // Write File closed
    fclose(fp);

    return 0;
}

