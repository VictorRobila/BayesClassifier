/*
Bayes_Rule.c

PURPOSE

    Thus subroutine uses bayes rule to guess the class of each measurement using the class conditional probability arrays and assigns each measurement a class

INPUT ARGUMENTS

class_conditional: This is the float two dimentional class conditional array
cifd: An empty two dimensional float array for use in classification
assign: An empty integer one dimentional array that will be filled with the assigned classes
cdim: The number of classes
ddim: The number of measurements in all of the arrays

OUTPUT

An array with all the assigned classes

*/
#include "stdio.h"
#include "math.h"

void Bayes_Rule (float **class_conditional, float **cifd, int *assign, int cdim, int ddim){
    // These are the P(c1) and P(c2) in the bayes rule
    float p = 1/(float)cdim;
    printf("%0.5f\n",p);
    int bestPos = 0;
    int k;
    
    for (int i=0; i<ddim; i++){
        float denominator=0;  
        for (int j=0; j<cdim; j++){
            denominator += class_conditional[j][i]*p;
        }
        int best=0;
        float bestval=-1;
        
        for (int j=0; j<cdim; j++){
            cifd[j][i]=class_conditional[j][i]*p/denominator;
            if (bestval<cifd[j][i]){
                best=j;
                bestval=cifd[j][i];
            }
        }
        assign[i]=best+1;
    }
}