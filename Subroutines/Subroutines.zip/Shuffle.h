/*
Shuffle.c

PURPOSE

    This subroutine randomly shuffles the one dimentional integer array that it is given

INPUT ARGUMENTS

array: This is an integer array. In Bayes_Classifer2.c it is the true class array.
dim1: The first dimension. This will be the number elements in the array.


OUTPUT

A randomly shuffled one dimentional integer array

*/

// These includes are necessary for the randomization function.
#include <stdlib.h>
#include <time.h>


void shuffle(int * arr, int size, int seed){
    srand((unsigned int)seed);
    for (int i = 0; i < size; i++) {
        int j = rand() % size;
        int t = arr[i];
        arr[i] = arr[j];
        arr[j] = t;
    }
}
