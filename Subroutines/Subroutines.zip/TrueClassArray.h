/*
TrueClassArray.c

PURPOSE

    This subroutine creates the true class array in a program. The first half of the array is filled with 2s and the second is filled with 0s.
    This will later be randomly shuffled

INPUT ARGUMENTS

array: An empty array that will be filled with the classes. This is an integer since all it's values are 1 or 0.
measurements: The number of measurements needed. This is an integer


OUTPUT

An array filled with 1s and 0s (first half 1s, second half 0s) that can be called in another function.

*/
#include "stdio.h"
#include "time.h"

void trueClassArray(int * array, int measurements, int cdim){
    //printf("FIVE\n");
    // This for loop goes through the first half of the array
    for (int j=0; j<cdim; j++){
        for (int i=0; i<measurements; i++){
            array[j*measurements+i]=j+1;
        }
    }
    printf("True Class Array Has Been Filled \n");
        
}