/*
FillClassArray.c

PURPOSE

    This function creates two normalized class conditional probability arrays from the true classes and probabilities

INPUT ARGUMENTS

class1array: This is a one dimensional empty float array that will be filled in this function
class2array: This is a one dimensional empty float array that will be filled in this function
trueClass: This is the integer true class array for each measurement
prob: This is the 2d float array of normalized probabilties for each class and measurment
dim1: This is the amount of measurements in all of the arrays

OUTPUT

Two normalized float class conditional probability arrays, one for each class

*/
#include "stdio.h"
#include "PrintFloatArray.h"

void fillClassArray(float **classarray, int *trueClass, float *prob, int cdim, int ddim, float PERT, int seed){
    // These are the two sums that will be used for normalization. They start at 0 since the arrays are empty.
    float valP;
    float sum;
    float temp;
    float newValP;

    printf("Filling Class Array\n");

    for (int i=0; i<ddim; i++){
        // This for loop goes through all elements of the true class array
        for (int j=0; j<cdim; j++)
            classarray[j][i] = 0;
        classarray[trueClass[i]-1][i] = prob[i];
    }
    printf("Class Array Filled");

    printFloatArray(classarray,cdim, ddim);
    srand((unsigned int)seed);
    //go over all observations
    for (int i=0; i<ddim; i++){
        // This for loop goes through all elements of the true class array
        temp = classarray[trueClass[i]-1][i];
        valP = PERT*temp;
        for (int j=0; j<cdim; j++){
            newValP = valP/(cdim);//*(rand()%10+1)/10.0;
            classarray[j][i] = newValP;
        }
        newValP = valP;//*(rand()%10+1)/10.0; //this is wrong, need to fix
        classarray[trueClass[i]-1][i] = temp-valP+valP/(cdim);
    }
    printf("2nd class array\n");

}